-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2020 at 12:28 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banhang`
--

-- --------------------------------------------------------

--
-- Table structure for table `donhang`
--

CREATE TABLE `donhang` (
  `madh` varchar(20) NOT NULL,
  `nguoinhan` varchar(20) NOT NULL,
  `sdt` varchar(20) NOT NULL,
  `diachi` varchar(50) NOT NULL,
  `gia` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donhang`
--

INSERT INTO `donhang` (`madh`, `nguoinhan`, `sdt`, `diachi`, `gia`) VALUES
('1', 'le tuan anh', '0916070889', '12 Ngã tư sở, Hà Nội', '3220000');

-- --------------------------------------------------------

--
-- Table structure for table `giohang`
--

CREATE TABLE `giohang` (
  `id` varchar(20) NOT NULL,
  `madh` varchar(20) NOT NULL,
  `masp` varchar(20) NOT NULL,
  `size` int(11) NOT NULL,
  `sl` int(11) NOT NULL,
  `gia` varchar(20) NOT NULL,
  `trangthai` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `giohang`
--

INSERT INTO `giohang` (`id`, `madh`, `masp`, `size`, `sl`, `gia`, `trangthai`) VALUES
('0', '0', '0', 0, 0, '0', NULL),
('vantue1999', '1', 'A61039', 38, 4, '2320000', 3),
('vantue1999', '1', 'A61051', 38, 2, '900000', 3);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`id`, `name`, `password`, `email`) VALUES
('vantue1999', 'le tuan anh', '123456', 'anhlt5199@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `quanly`
--

CREATE TABLE `quanly` (
  `id` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quanly`
--

INSERT INTO `quanly` (`id`, `password`) VALUES
('', ''),
('', ''),
('quanly', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `masp` varchar(20) NOT NULL,
  `tensp` varchar(50) NOT NULL,
  `kieu` varchar(20) NOT NULL,
  `mau` varchar(20) NOT NULL,
  `thongtin` text NOT NULL,
  `gia` varchar(20) NOT NULL,
  `gioitinh` varchar(20) NOT NULL,
  `giamgia` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`masp`, `tensp`, `kieu`, `mau`, `thongtin`, `gia`, `gioitinh`, `giamgia`) VALUES
('A21004', 'Urbas The Ocean', 'Slip On', 'Poseidon', 'Vì đại dương đâu chỉ có một màu, và vì con trai con gái đâu chỉ mang riêng một sắc thái. Urbas \"The Ocean\" Pack - với tông màu trendy, chất liệu da Suede phủ trọn trên dáng Slip On cổ điển hợp mọi giới tính - sẽ biến những khoảnh khắc đời thường trở nên rực rỡ, sống động.', '390000', 'male', '0'),
('A41002', 'Urbas The Ocean', 'Low Top', 'Coral Snow', 'Vì đại dương đâu chỉ có một màu, và vì con trai con gái đâu chỉ mang riêng một sắc thái. Urbas \"The Ocean\" Pack - với tông màu trendy, chất liệu PU phủ trọn trên dáng Low Top cổ điển hợp mọi giới tính - sẽ biến những khoảnh khắc đời thường trở nên rực rỡ, sống động.', '490000', 'female', '20'),
('A61005', 'Basas New Simple Life', 'Low Top', 'Taupe', 'Thuộc dòng Basas với nét tối giản đặc trưng cùng khả năng kết hợp mọi outfit thường ngày, Basas \"New Simple Life\" dành cho những con người đơn giản nhưng không đơn điệu, bình thường mà chẳng tầm thường. Dáng Low Top cổ điển, không bao giờ lỗi thời chính là sự lựa chọn dễ chịu cho những ngày vô lo, vô nghĩ.\r\n', '420000', 'male', '0'),
('A61039', 'Vintas Mister', 'Low Top', 'Narcissuede', 'Dáng Low Top truyền thống, kết hợp cùng phối màu gợi nét cổ điển, xưa cũ với chất liệu da Suede. Một sự lựa chọn của những ai muốn làm nổi bật lên sự chín chắn, tính điềm đạm cùng nét lịch thiệp cho bộ outfit của mình.', '580000', 'male', '30'),
('A61047', 'Vintas Yesterday', 'Slip On', 'Taupe Leather', 'Sử dụng đồng thời chất liệu da Nappa và vải Canvas, \"Yesterday\" gợi cho người nhìn một cảm giác vừa cổ điển, vừa tân thời. Nếu bạn bất giác cảm thấy bản thân đang ở độ tuổi lưng chừng, chưa già nhưng cũng qua thời tuổi trẻ, có lẽ bạn chính là tuýp người \"ngày hôm qua\" chăng?\r\n', '330000', 'female', '0'),
('A61050', 'Urbas The Gang', 'Low Top', 'Haute Black', 'Cùng sở hữu một màu đen chủ đạo và chỉ khác nhau phần màu được nhấn nhá ở đế và đỉnh hậu, Urbas \"The Gang\" là hình ảnh của nhóm bạn thân với nhiều mảnh ghép, nhiều tính cách trái ngược nhưng vẫn có sự kết nối đầy tích cực, lạc quan.', '450000', 'female', '35'),
('A61051', 'Urbas The Gang', 'Low Top', 'Ceramic Black', 'Cùng sở hữu một màu đen chủ đạo và chỉ khác nhau phần màu được nhấn nhá ở đế và đỉnh hậu, Urbas \"The Gang\" là hình ảnh của nhóm bạn thân với nhiều mảnh ghép, nhiều tính cách trái ngược nhưng vẫn có sự kết nối đầy tích cực, lạc quan.\r\n', '450000', 'female', '15'),
('A61066', 'Basas New Simple Life', 'Low Top', 'Cordovan', 'Thuộc dòng Basas với nét tối giản đặc trưng, khả năng kết hợp mọi outfit thường ngày, Basas \"New Simple Life\" dành cho những con người đơn giản nhưng không đơn điệu, bình thường mà chẳng tầm thường. Dáng Low Top cổ điển, không bao giờ lỗi thời chính là sự lựa chọn dễ chịu cho những ngày vô lo, vô nghĩ.\r\n', '420000', 'male', '15'),
('A61067', 'Basas Black Lace ', 'Low Top', 'Dark Grey', 'Vẫn sử dụng những màu sắc cơ bản của Basas, \"Basas Black Lace\" Pack trở nên mạnh mẻ, ấn tượng hơn khi sử dụng dây giày màu đen làm điểm nhấn cho bản phối màu trắng-đen-xám tưởng chừng quá quen thuộc. Dáng giày low top cổ điển, đây sẽ là một lựa chọn an toàn nhưng không nhàm chán.', '450000', 'female', '0'),
('A61079', 'Basas Mono', 'High Top', 'Dark Grey', 'Dáng giày high top cá tính, kết hợp upper và phần đế \"ton-sur-ton\" đã giúp \"Basas Mono\" Pack trở nên thu hút. Đôi giày này hứa hẹn sẽ là một điểm nhấn thú vị cho mọi set đồ của bạn.', '490000', 'female', '20'),
('A61090', 'Urbas Corluray', 'Low Top', 'Faded Pink ', 'Lấy cảm hứng từ kì nghỉ Xuân 2020 \"dài hạn đặc biệt\" vượt qua cả mùa Hạ để chạm đến mùa Thu, “Corluray Pack” ra đời với nét cách điệu mới mẻ, hiếm thấy ở dòng Urbas. Chất liệu Corduroy với tên gọi khác Elephant Cord (nhung gân sợi to) lần đầu tiên được sử dụng trên thân giày, gây ấn tượng cùng những phối màu như những tia nắng cuối Xuân ấm áp.\r\n', '590000', 'female', '0'),
('A61092', 'Urbas Corluray', 'High Top', 'Grasses', 'Lấy cảm hứng từ kì nghỉ Xuân 2020 \"dài hạn đặc biệt\" vượt qua cả mùa Hạ để chạm đến mùa Thu, “Corluray Pack” ra đời với nét cách điệu mới mẻ, hiếm thấy ở dòng Urbas. Chất liệu Corduroy với tên gọi khác Elephant Cord (nhung gân sợi to) lần đầu tiên được sử dụng trên thân giày, gây ấn tượng cùng những phối màu như những tia nắng cuối Xuân ấm áp.', '650000', 'male', '10'),
('A61097', 'Lucky Luke Pattas ', 'Low Top', 'Light Blue', 'Phiên bản \"ưu ái\" dành riêng cho chú chó Rantanplan, vốn để lại ấn tượng ngốc nghếch rõ nét trong bộ truyện Lucky Luke. Sử dụng sắc thái khuôn mặt hài hước và dỉ dỏm, kết hợp phom dáng Low Top trên nền xanh chủ đạo. Chắc chắn chinh phục những bạn trẻ đang tìm thêm sắc màu trẻ trung cho cuộc sống.', '790000', 'male', '0'),
('A61100', 'Vintas Bleached Sand ', 'Low Top', 'Roasted Sand', 'Sử dụng kết hợp chất canvas thông thường cùng chi tiết da lộn trên nền màu trầm đậm, táo bạo mà phá cách. Gợi nhắc cá tính riêng biệt, đặc trưng của những tâm hồn yêu thiên nhiên, thích phiêu lưu đó đây.', '550000', 'female', '0'),
('A61101', 'Vintas Mister', 'High Top', 'Chocolate Brown', 'Công thức pha trộn từ hai chất liệu vải và da lộn đặc trưng, điều thường thấy ở bộ Vintas Mister. Sự kết hợp mạnh mẽ tạo nên nét cổ điển, hoài niệm. Chắc chắn là sự lựa chọn \"hết bài\" cho những con người trầm tính và điềm đạm.', '610000', 'male', '0'),
('A61102', 'Urbas Unsettling', 'Low Top', 'Starlight/Lavender', 'Sở hữu công thức pha màu \"khó chịu\". Urbas Unsettling tạo nên điểm nhấn mạnh mẽ, gây kích thích thị giác thông qua sự đối lập trong từng gam màu. Điểm chốt hạ cho một outfit đặc biệt thú vị, tách biệt khỏi sự trùng lặp thông thường.', '490000', 'female', '20'),
('A61107', 'Urbas Unsettling', 'High Top', 'Insignia/Sulphur', 'Sở hữu công thức pha màu \"khó chịu\". Urbas Unsettling tạo nên điểm nhấn mạnh mẽ, gây kích thích thị giác thông qua sự đối lập trong từng gam màu. Điểm chốt hạ cho một outfit đặc biệt thú vị, tách biệt khỏi sự trùng lặp thông thường.', '550000', 'female', '0'),
('A6T001', 'TRACK 6 OG', 'Low Top', '70s White', 'Với cảm hứng từ Retro Sneakers và âm nhạc giai đoạn 1970s, Ananas Track 6 ra đời với danh hiệu là mẫu giày Cold Cement đầu tiên của Ananas - một thương hiệu giày Vulcanized. Chất liệu Storm Leather đáng giá \"càn quét\" toàn bộ bề mặt upper cùng những chi tiết thiết kế đặc trưng và mang nhiều ý nghĩa. Chắc rằng, Track 6 sẽ đem đến cho bạn sự tự nhiên thú vị như chính thông điệp bài hát Let it be của huyền thoại The Beatles gửi gắm.', '990000', 'female', '0'),
('A6T004', 'Track 6 Suede', 'Low Top', 'Meadow', 'Mang nét ngoài bắt mắt với gam màu lấy cảm hứng từ thiên nhiên mùa thu, Ananas Track 6 Suede Meadow lần này được sử chất liệu da lộn bền bỉ mà quen thuộc. Không đơn thuần chỉ đem nét mới mẻ đến cho những người yêu mến Track 6, phiên bản còn là yếu tố ấn định những khoảnh khắc đời thường thêm phần sắc màu thú vị.', '990000', 'male', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donhang`
--
ALTER TABLE `donhang`
  ADD PRIMARY KEY (`madh`);

--
-- Indexes for table `giohang`
--
ALTER TABLE `giohang`
  ADD PRIMARY KEY (`id`,`madh`,`masp`,`size`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`masp`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
